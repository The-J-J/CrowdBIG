﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registering_Process
{
    public class UserClass
    {
        public double V { get; set; }

        string Name;
        /*
        int Age;
        string PhoneNumber;
        string E_Mail;
        string NameOfMobileDevice;
        int CameraResolution;
        string TypeOfInternet;
        string Education;
        string Training; */

        public UserClass(double v)
        {
            V = v;

            Console.WriteLine("                 Hi Dear User! \nIt's a Registeration Process! Please Follow Me...             ");
            Console.WriteLine();
            Console.Write(" Please Enter Your Name : ");
            Name = Console.ReadLine();
            /*
            Console.Write(" Please Enter Your Age : ");
            Age = Convert.ToInt32(Console.ReadLine());
            Console.Write(" Please Enter Your Phone Number With 0 : ");
            PhoneNumber = Console.ReadLine();
            Console.Write(" Please Enter Your E-Mail : ");
            E_Mail = Console.ReadLine();
            Console.Write(" Please Enter Your Name of Mobile Device : ");
            NameOfMobileDevice = Console.ReadLine();
            Console.Write(" Please Enter Your Camera Resolution Value : ");
            CameraResolution = Convert.ToInt32(Console.ReadLine());
            Console.Write(" Please Enter Your Type of Internet (2G or 3G or 4G or 5G) : ");
            TypeOfInternet = Console.ReadLine();
            Console.Write(" Please Enter Your Education : \n Education = Illiterate or Primary or Secondary or University : ");
            Education = Console.ReadLine();
            Console.Write("Have You Had Any Training in This Context ? -->  Yes Or No : ");
            Training = Console.ReadLine();
            */
            Console.WriteLine("\n\n");

        }
        public string GetInfo()
        {


            return "Name : " + Name;
                /* + "\n  Age : " + Age + "\n  Phone Number : " + PhoneNumber +
                "\n  E-Mail : " + E_Mail + "\n  Name of Mobile Device : " + NameOfMobileDevice +
                "\n  Camera Resolution :" + CameraResolution +
                "\n  Type of Internet : " + TypeOfInternet +
                "\n  Education : " + Education +
                "\n  Training : " + Training; */
        }
    }
}
