﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Registering_Process
{
    class Program
    {
        const int userCount = 6;
        static double[] v = new double[userCount]
        {
            0.25, 0.5, 0.75, 0.85, 1.25, 1.5     /* Varians of Users 1 to 6 */
        };

        static void Main(string[] args)
        {
            UserClass[] users = new UserClass[userCount];

            for (int i = 0; i < userCount; i++)
                users[i] = new UserClass(v[i]);

            Validator validator = new Validator();
            validator.ValidateUsers(users, "RegistrationProcess.txt");

            Console.WriteLine("\n ***** Finished *****");
            Console.WriteLine(" Please Enter a key To see Results : ");
            Console.ReadKey();
        }
    }
}
