﻿using Extreme.Statistics.Distributions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registering_Process
{
    public class Validator
    {
        const int KeyCount = 4;
        const int KeyLength = 20;
        const int TotalLength = KeyCount * KeyLength;

        private int[] Keys = new int[TotalLength]
        {
                2,1,2,4,1,3,3,2,4,4,1,2,3,2,2,1,3,4,1,3, /* Key 1 */
                3,1,4,2,2,1,1,4,3,2,2,2,3,4,4,1,1,3,1,3, /* Key 2 */
                4,1,3,2,1,2,2,4,1,3,3,1,2,3,1,4,4,2,2,1, /* Key 3 */
                2,1,1,4,3,1,1,3,2,4,1,2,4,3,3,1,2,1,4,4, /* Key 4 */
        };

        private string GetKeyString()
        {
            string output = "Keys:";
            int counter = 0;
            for (int i = 0; i < TotalLength; i++)
            {
                int iden = i % KeyLength;
                if (iden == 0)
                    output += "\nKey " + ++counter + ":";
                output += "\t" + Keys[i];
            }
            return output;
        }

        public void ValidateUsers(UserClass[] users, string outputFilePath)
        {
            string output = GetKeyString();
            foreach (var user in users)
            {
                output += "\n\n" + user.GetInfo() + "\n";

                int diff = 0;
                int noneZero = 0;
                int counter = 0;
                for (int i = 0; i < TotalLength; i++)
                {
                    NormalDistribution distribution = new NormalDistribution(Keys[i], user.V);
                    int q = (int)Math.Round(distribution.Sample(), MidpointRounding.AwayFromZero);
                    q = (q % 5 + 5) % 5;

                    int iden = i % KeyLength;
                    if (iden == 0)
                        output += "\nQ" + ++counter + ":";
                    output += "\t" + q;

                    if (q != 0)
                    {
                        noneZero++;
                        if (q != Keys[i])
                            diff++;
                    }
                }

                double dnRatio = noneZero == 0 ? 1.0 : Math.Round((double)diff / noneZero, 2);
                bool malicious = dnRatio >= 0.5;
                output += malicious ? "\n\nThe user is malicious ratio: " + dnRatio + "\n\n" : "\n\nThe user is honest ratio: " + dnRatio + "\n\n";
            }

            System.IO.File.WriteAllText(outputFilePath, output);
        }
    }
}
