﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Registering_Process
{
    class Program
    {
        static void Main(string[] args)
        {
            List<User> users = new List<User>();
            using (StreamReader reader = File.OpenText("Samples.txt"))
            {
                while(!reader.EndOfStream)
                {
                    users.Add(new User(reader));
                }
            }

            Validator validator = new Validator();
            validator.ValidateUsers(users, "Output.txt");

            Console.WriteLine("\n ***** Finished *****");
            Console.ReadKey();
        }
    }
}
