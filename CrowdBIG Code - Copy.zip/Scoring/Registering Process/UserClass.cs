﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registering_Process
{
    public class UserClass
    {
        public double V { get; set; }

        string Name;
        int Age;
        string PhoneNumber;
        string E_Mail;
        string NameOfMobileDevice;
        int CameraResolution;
        string TypeOfInternet;
        string Education;
        string Training;

        public UserClass(double v)
        {
            V = v;

            Console.WriteLine("              Hi! It's a Registery Process... Please Follow Me :) !              ");
            Console.WriteLine();
            Console.Write(" Please Enter Your Name : ");
            Name = Console.ReadLine();
            //Console.Write(" Please Enter Your Age : ");
            //Age = Convert.ToInt32(Console.ReadLine());
            //Console.Write(" Please Enter Your Phone Number : ");
            //PhoneNumber = Console.ReadLine();
            //Console.Write(" Please Enter Your E-Mail : ");
            //E_Mail = Console.ReadLine();
            //Console.Write(" Please Enter Your Name of Mobile Device : ");
            //NameOfMobileDevice = Console.ReadLine();
            //Console.Write(" Please Enter Your Camera Resolution : ");
            //CameraResolution = Convert.ToInt32(Console.ReadLine());
            //Console.Write(" Please Enter Your Type of Internet : ");
            //TypeOfInternet = Console.ReadLine();
            //Console.Write(" Please Enter Your Education : ");
            //Education = Console.ReadLine();
            //Console.Write("Have You done Training in This Context ?  -->  Yes Or No : ");
            //Training = Console.ReadLine();

        }
        public string GetInfo()
        {


            return "Name : " + Name + "  Age : " + Age + "  Phone Number : " + PhoneNumber +
                "  E-Mail : " + E_Mail + "  Name of Mobile Device : " + NameOfMobileDevice +
                "  Camera Resolution :" + CameraResolution +
                "  Type of Internet : " + TypeOfInternet +
                "  Education : " + Education +
                "  Training : " + Training;
        }
    }
}
