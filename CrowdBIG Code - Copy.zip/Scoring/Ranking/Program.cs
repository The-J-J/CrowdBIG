﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Registering_Process
{
    class Program
    {
        const int UserCount = 6;
        const int R = 3;
        static double[] V = new double[UserCount]
        {
            0.25, 0.5, 0.75, 1.0, 1.25, 1.5
        };

        static void Main(string[] args)
        {
            User[] users = new User[UserCount];
            Random random = new Random();
            int[] nopTotal = new int[R];

            for (int i = 0; i < UserCount; i++)
            {
                Console.Write("Name: ");
                string name = Console.ReadLine();
                int[] nop = new int[R];
                for (int r = 0; r < R; r++)
                {
                    nop[r] = random.Next(5, 10);
                    nopTotal[r] += nop[r];
                }
                users[i] = new User(name, V[i], nop, R);
            }

            Validator validator = new Validator();
            validator.ValidateUsers(users, nopTotal, R);

            Array.Sort(users, new Comparison<User>((u1, u2) =>
            {
                if (u1.ReputationScore < u2.ReputationScore)
                    return 1;
                if (u1.ReputationScore == u2.ReputationScore)
                    return 0;
                return -1;
            }));

            Console.WriteLine("\n ***** Finished *****");

            string output = "";
            output = "  ******************************************\t\t\t Summary of 6 Users Participations in 3 Regions\t\t\t ****************************************** ";
            for (int r = 0; r < R; r++)
            {
                output += "\n\n\n **********\t Region " + (r + 1).ToString() + "\t**********\n\n";
                output += validator.GetRegionKeysString(r);
                foreach (var user in users)
                {
                    output += "\n\n\n\tName : " + user.Name;
                    output += "\n\tNumber of Participations = " + user.NOP[r].ToString();
                    output += "\n\tNumber of Answered Questions = " + user.NOAQRegion[r].ToString();
                    output += "\n\tNumber of Unmalicious Participations = " + user.NOUMP[r].ToString();
                    output += "\n\tUsefulness Rate = " + user.UsefulnessRate[r].ToString() + '\n';
                    for (int i = 0; i < user.NOP[r]; i++)
                    {
                        output += "\n Questionnaire " + (i + 1).ToString() + ":\t";
                        for (int j = 0; j < 20; j++)
                            output += user.Q[r][i][j].ToString() + '\t';
                        output += "\tParticipation Outlier Rate (POR) = " + user.DNRatio[r][i].ToString() + '\t' + "\tMalicious ? -->\t" + user.GetMalicious(user.DNRatio[r][i]).ToString() + '\n';
                    }
                   
                }
            }

            output += "\n\n\n\tOverall (Ranking by Reputation Score ) \n\n";

            for (int i = 0; i < users.Length; i++)
            {
                output += "\n\t\t\tName:  " + users[i].Name;
                output += "\n\tUser Useful Participation =  " + users[i].UUP.ToString();
                output += "\n\tInformation Completeness =  " + users[i].IC.ToString();
                output += "\n\tReputation Score =  " + users[i].ReputationScore.ToString() + '\n';
            }

            File.WriteAllText("Result.txt", output);

            Console.ReadKey();
        }
    }
}
