﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registering_Process
{
    public class User
    {
        public double V { get; }
        public string Name { get; }
        public int[] NOP { get; }
        public int[] NOUMP { get; }
        public int[] NOAQRegion { get; set; }
        public List<List<int>>[] Q { get; set; }
        public List<double>[] DNRatio { get; set; }
        public double[] UsefulnessRate { get; set; }
        public double UUP { get; set; }
        public double IC { get; set; }
        public double ReputationScore { get; set; }
        public int NOAQTotal { get; set; }

        public int GetNOMP(int r)
        {
            return NOP[r] - NOUMP[r];
        }

        public int GetNOPTotal()
        {
            int sum = 0;
            for (int i = 0; i < NOP.Length; i++)
                sum += NOP[i];
            return sum;
        }

        public int GetNopEnviornment()
        {
            int sum = 0;
            for (int r = 0; r < NOP.Length; r++)
                sum += NOP[r];
            return sum;
        }

        public string GetQString(int r, int keyLength)
        {
            string output = "";
            for (int i = 0; i < NOP[r]; i++)
            {
                for (int j = 0; j < keyLength; j++)
                    output += Q[r][i][j] + '\t';
                output += '\n';
            }
            return output;
        }

        public bool GetMalicious(double ratio)
        {
            if (ratio > 0.5)
                return true;
            return false;
        }

        public User(string name, double v, int[] nop, int r)
        {
            Name = name;
            V = v;
            NOP = nop;
            NOUMP = new int[r];
            NOAQRegion = new int[r];
            Q = new List<List<int>>[r];
            DNRatio = new List<double>[r];
            for (int i = 0; i < r; i++)
            {
                Q[i] = new List<List<int>>();
                DNRatio[i] = new List<double>();
            }
            UsefulnessRate = new double[r];
        }
    }
}
