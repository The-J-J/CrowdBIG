﻿using Extreme.Statistics.Distributions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registering_Process
{
    public class Validator
    {
        const int KeyLength = 20;
        private List<List<int[]>> Keys = new List<List<int[]>>
        {
                /* Region 1 */
                new List<int[]>()
                {
                     /* Key 1 */ new int[]{2,1,2,4,1,3,3,2,4,4,1,2,3,2,2,1,3,4,1,3},
                     /* Key 2 */ new int[]{3,1,4,2,2,1,1,4,3,2,2,2,3,4,4,1,1,3,1,3},
                     /* Key 3 */ new int[]{4,1,3,2,1,2,2,4,1,3,3,1,2,3,1,4,4,2,2,1},
                     /* Key 4 */ new int[]{2,1,1,4,3,1,1,3,2,4,1,2,4,3,3,1,2,1,4,4},
                     /* Key 5 */ new int[]{1,4,2,3,2,4,2,1,3,4,4,2,3,1,1,3,4,2,1,1},
                     /* Key 6 */ new int[]{2,1,2,4,1,3,2,2,4,4,1,2,3,2,2,1,3,4,1,3},
                     /* Key 7 */ new int[]{3,1,4,2,2,1,1,4,3,1,2,2,3,0,4,1,1,3,1,3},
                     /* Key 8 */ new int[]{4,1,3,2,1,2,3,4,1,3,3,1,2,2,1,4,4,2,2,1},
                     /* Key 9 */ new int[]{2,1,1,4,3,1,1,2,2,4,1,2,4,3,3,1,2,1,4,4},
                     /* Key 10 */ new int[]{4,3,1,4,3,1,3,2,1,2,1,2,4,3,3,1,2,1,4,4}
                },

                /* Region 2 */
                new List<int[]>()
                {
                     /* Key 1 */ new int[]{4,3,1,4,3,1,3,2,1,2,1,2,4,3,3,1,2,1,4,4},
                     /* Key 2 */ new int[]{2,1,1,4,3,1,1,2,2,4,1,2,4,3,3,1,2,1,4,4},
                     /* Key 3 */ new int[]{4,1,3,2,1,2,3,4,1,3,3,1,2,2,1,4,4,2,2,1},
                     /* Key 4 */ new int[]{3,1,4,2,2,1,1,4,3,1,2,2,3,0,4,1,1,3,1,3},
                     /* Key 5 */ new int[]{2,1,2,4,1,3,2,2,4,4,1,2,3,2,2,1,3,4,1,3},
                     /* Key 6 */ new int[]{1,1,3,3,1,3,2,2,4,4,1,2,3,2,2,1,3,4,2,3},
                     /* Key 7 */ new int[]{4,1,4,2,2,4,1,2,2,1,2,2,3,0,4,1,1,3,1,3},
                     /* Key 8 */ new int[]{2,3,3,2,1,2,3,4,1,3,3,1,2,2,1,4,4,2,2,1},
                     /* Key 9 */ new int[]{2,1,1,4,3,1,1,1,3,4,1,2,4,3,3,1,2,1,3,3},
                     /* Key 10 */ new int[]{4,3,1,2,2,1,3,2,1,2,1,2,4,3,3,1,2,1,1,1}
                },

                 /* Region 3 */
                new List<int[]>()
                {
                     /* Key 1 */ new int[]{2,3,1,4,3,1,3,2,3,2,1,2,4,3,3,1,2,1,4,4},
                     /* Key 2 */ new int[]{3,1,1,4,3,1,1,2,2,4,1,2,4,3,3,1,2,1,4,4},
                     /* Key 3 */ new int[]{1,1,3,2,1,2,3,4,4,3,3,1,2,2,1,4,4,2,2,1},
                     /* Key 4 */ new int[]{1,1,4,2,2,1,1,4,2,1,2,2,3,0,4,1,1,3,1,3},
                     /* Key 5 */ new int[]{2,1,2,4,1,3,2,2,1,4,1,2,3,2,2,1,3,4,1,3},
                     /* Key 6 */ new int[]{4,1,3,3,1,3,2,2,1,4,1,2,3,2,2,1,3,4,2,3},
                     /* Key 7 */ new int[]{2,1,4,2,2,4,1,2,2,1,2,2,3,0,4,1,1,3,1,3},
                     /* Key 8 */ new int[]{1,3,3,2,1,2,3,4,1,3,3,1,2,2,1,4,4,2,2,1},
                     /* Key 9 */ new int[]{3,1,1,4,3,1,1,1,4,4,1,2,4,3,3,1,2,1,3,3},
                     /* Key 10 */ new int[]{4,3,1,2,2,1,3,2,3,2,1,2,4,3,3,1,2,1,1,1}
                }
        };

        public string GetRegionKeysString(int r)
        {
            string output = "";
            for (int k = 0; k < 10; k++)
            {
                output += "Key " + (k + 1).ToString() + ":\t";
                for (int i = 0; i < KeyLength; i++)
                    output += Keys[r][k][i].ToString() + '\t';
                output += '\n';
            }
            return output;
        }

        public void ValidateUsers(User[] users, int[] nopTotal, int R)
        {
            int[] noupTotal = new int[R];

            for (int r = 0; r < R; r++)
            {
                foreach (var user in users)
                {
                    int noumpI = 0;
                    for (int i = 0; i < user.NOP[r]; i++)
                    {
                        List<int> uQ = new List<int>();
                        int noneZero = 0;
                        int diff = 0;
                        for (int j = 0; j < KeyLength; j++)
                        {
                            NormalDistribution distribution = new NormalDistribution(Keys[r][i][j], user.V);
                            int q = (int)Math.Round(distribution.Sample(), MidpointRounding.AwayFromZero);
                            q = (q % 5 + 5) % 5;
                            uQ.Add(q);

                            if (q != 0)
                            {
                                noneZero++;
                                if (q != Keys[r][i][j])
                                    diff++;
                            }
                        }
                        double dnRatio = noneZero == 0 ? 1.0 : Math.Round((double)diff / noneZero, 2);
                        bool malicious = user.GetMalicious(dnRatio);

                        if (!malicious)
                            noumpI++;

                        user.Q[r].Add(uQ);
                        user.DNRatio[r].Add(dnRatio);

                        user.NOAQRegion[r] += noneZero;
                    }
                    user.NOUMP[r] = noumpI;
                    noupTotal[r] += noumpI;
                }
            }


            foreach (var user in users)
            {
                for (int r = 0; r < R; r++)
                {
                    user.UsefulnessRate[r] = (double)user.NOUMP[r] / noupTotal[r];
                    user.UUP += user.UsefulnessRate[r];
                    user.NOAQTotal += user.NOAQRegion[r];
                }
                user.IC = (double)user.NOAQTotal / (KeyLength * user.GetNOPTotal());
                user.ReputationScore = (user.UUP + user.IC) / 2.0;
            }
        }
    }
}
