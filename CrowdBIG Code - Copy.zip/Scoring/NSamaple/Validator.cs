﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registering_Process
{
    public class Validator
    {
        const int KeyCount = 4;
        const int KeyLength = 20;
        const int TotalLength = KeyCount * KeyLength;

        private int[] Keys = new int[TotalLength]
        {
                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1, /* Key 1 */
                3,1,4,2,2,1,1,4,3,2,2,2,3,4,4,1,1,3,1,3, /* Key 2 */
                4,1,3,2,1,2,2,4,1,3,3,1,2,3,1,4,4,2,2,1, /* Key 3 */
                2,1,1,4,3,1,1,3,2,4,1,2,4,3,3,1,2,1,4,4, /* Key 4 */
        };

        private string GetKeyString()
        {
            string output = "Keys:";
            int counter = 0;
            for (int i = 0; i < TotalLength; i++)
            {
                int iden = i % KeyLength;
                if (iden == 0)
                    output += "\nKey " + ++counter + ":";
                output += "\t" + Keys[i];
            }
            return output;
        }

        public void ValidateUsers(List<User> users, string outputFilePath)
        {
            string output = GetKeyString();
            int selfishTh = 2;
            foreach (var user in users)
            {
                output += "\n\n" + user.Name;

                int th = 10;
                List<int> sThIden = new List<int>();
                for (int q = 0; q < 4; q++)
                {
                    output += "\nQ" + q + ":\t";
                    for (int len = 1; len < 10; len++)
                    {
                        int count = 0;
                        for (int index = 0; index + len < 20; index++)
                        {
                            if (user.Q[q * 20 + index] == user.Q[q * 20 + index + len])
                            {
                                count += 2;
                                if (count > th)
                                {
                                    if (!sThIden.Contains(q))
                                        sThIden.Add(q);
                                    output += "Pattern: ";
                                    for (int item = 0; item < len; item++)
                                    {
                                        output += user.Q[q * 20 + item] + " ";
                                    }
                                    output += "\t";
                                    break;
                                }
                            }
                            else
                                break;
                        }
                    }
                }
                if (sThIden.Count >= selfishTh)
                    output += "\nThis user is selfish";
            }

            System.IO.File.WriteAllText(outputFilePath, output);
        }
    }
}
