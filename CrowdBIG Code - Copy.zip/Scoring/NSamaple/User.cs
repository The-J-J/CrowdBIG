﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registering_Process
{
    public class User
    {
        public string Name { get; }
        public int[] Q { get; }

        public User(StreamReader reader)
        {
            Q = new int[80];
            Name = reader.ReadLine();
            int index = 0;
            for (int i = 0; i < 4; i++)
            {
                string line = reader.ReadLine();
                string[] parts = line.Split('\t');
                for (int j = 1; j <= 20; j++)
                    Q[index++] = int.Parse(parts[j]);
            }
        }
    }
}
